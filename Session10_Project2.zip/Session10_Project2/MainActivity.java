package com.example.session10project2.session10project2;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends Activity implements AdapterView.OnItemSelectedListener {

    SqlHandler sqlHandler;
    EditText itemname, itemprice, totalexpences, date;
    //String category;
    Button save , list;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        itemname = (EditText) findViewById(R.id.et_itemname);
        itemprice = (EditText) findViewById(R.id.et_itemprice);
        totalexpences = (EditText) findViewById(R.id.et_totalexpence);
        date = (EditText) findViewById(R.id.et_date);
        //dtpicker = (DatePicker)findViewById(R.id.datePicker);
        save = (Button) findViewById(R.id.btn_submit);
        list = (Button) findViewById(R.id.btn_list);
        final Spinner spinner = (Spinner) findViewById(R.id.categoryspinner);

        spinner.setOnItemSelectedListener(this);

        List<String> categories = new ArrayList<String>();
        categories.add("Grocery");
        categories.add("Medical");

        categories.add("Education");
        categories.add("Personal");
        categories.add("Travel");

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);
        spinner.setOnItemSelectedListener(this);
        sqlHandler = new SqlHandler(this);


        /*final Spinner spinnerCategory = (Spinner) findViewById(R.id.categoryspinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.category, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapter);
        spinnerCategory.setOnItemSelectedListener(this);

*/
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //String cat = category.getText().toString();
                String nm = itemname.getText().toString();
                String price = itemprice.getText().toString();
                String dt = date.getText().toString();
                String totexp = totalexpences.getText().toString();
                String cat = spinner.toString();



                String query = "INSERT INTO Expences(expence_category,item_name,item_price,date,total_expences) values ('"
                        + cat + "','" + nm + "','" + price + "','" + dt + "','" + totexp + "')";

                sqlHandler.executeQuery(query);


                //category.setText("");
                itemname.setText("");
                itemprice.setText("");
                date.setText("");
                totalexpences.setText("");

            }
        });

        list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(getApplicationContext(), DisplayListActivity.class);
                startActivity(i);
            }
        });



    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // On selecting a spinner item
        String item = parent.getItemAtPosition(position).toString();


    }
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }




}
