package com.example.session10project2.session10project2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class SqlDbHelper extends SQLiteOpenHelper {

    public static final String DATABASE_TABLE = "Expences";

    public static final String COLUMN1 = "slno";
    public static final String COLUMN2 = "expence_category";
    public static final String COLUMN3 = "item_name";
    public static final String COLUMN4 = "item_price";
    public static final String COLUMN5 = "item_quantity";
    public static final String COLUMN6 = "date";
    public static final String COLUMN7 = "total_expences";

    private static final String CREATE_TABLE = "create table "
            + DATABASE_TABLE + " (" + COLUMN1
            + " integer primary key autoincrement, " + COLUMN2
            + " text not null, " + COLUMN3 + " text not null, " + COLUMN4 + " text not null, " + COLUMN5 + " text not null, " + COLUMN6 + " text not null, " + COLUMN7 + " text not null);";

    public SqlDbHelper(Context context, String name, CursorFactory factory,
                       int version) {
        super(context, name, factory, version);
        // TODO Auto-generated constructor stub

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub
        db.execSQL(CREATE_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
        onCreate(db);
    }

}
