package com.example.session10project2.session10project2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by trident on 6/6/16.
 */
public class ExpencesListAdapter extends BaseAdapter {

    Context context;
    ArrayList<ExpencesListItems> expencesList;

    public ExpencesListAdapter(Context context, ArrayList<ExpencesListItems> list) {
        this.context = context;
        expencesList = list;
    }



    @Override
    public int getCount() {

        return expencesList.size();
    }

    @Override
    public Object getItem(int position) {

        return expencesList.get(position);
    }

    @Override
    public long getItemId(int position) {

        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup arg2) {
        ExpencesListItems expencesListItems = expencesList.get(position);

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.row_layout, null);

        }
        TextView tvSlNo = (TextView) convertView.findViewById(R.id.slno);
        tvSlNo.setText(expencesListItems.getSlno());
        TextView tvitmnm = (TextView) convertView.findViewById(R.id.itemname);
        tvitmnm.setText(expencesListItems.getItem_name());
        TextView tvPrice = (TextView) convertView.findViewById(R.id.totalprice);
        tvPrice.setText(expencesListItems.getTotal_price());

        return convertView;
    }
}
