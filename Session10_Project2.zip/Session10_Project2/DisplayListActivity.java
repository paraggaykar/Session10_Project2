package com.example.session10project2.session10project2;

import java.util.ArrayList;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.*;

/**
 * Created by trident on 6/6/16.
 */
public class DisplayListActivity extends Activity  {

    SqlHandler sqlHandler;
    ListView lvExpencesListView;
    Button btndaily, btnweekly, btnmonthly;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display_list);

        btndaily = (Button) findViewById(R.id.daily);
        btnweekly = (Button) findViewById(R.id.weekly);
        btnmonthly = (Button) findViewById(R.id.monthly);
        sqlHandler = new SqlHandler(this);
        lvExpencesListView = (ListView) findViewById(R.id.lv_expences_list);

        btndaily.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.print("Daily Expences");
                showDailyExpences();
            }
        });

        btnweekly.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.print("Weekly Expences");
                showWeeklyExpences();
            }
        });

        btnmonthly.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.print("Weekly Expences");
                showMonthlyExpences();
            }
        });

    }


    public void showDailyExpences() {

        ArrayList<ExpencesListItems> expencesList = new ArrayList<ExpencesListItems>();
        expencesList.clear();
        String query = "SELECT * FROM Expences where date BETWEEN datetime('now', 'start of day') AND datetime('now', 'localtime')  ";

        Cursor c1 = sqlHandler.selectQuery(query);
        if (c1 != null && c1.getCount() != 0) {
            if (c1.moveToFirst()) {
                do {
                    ExpencesListItems expencesListItems = new ExpencesListItems();

                    expencesListItems.setSlno(c1.getString(c1
                            .getColumnIndex("slno")));
                    expencesListItems.setItem_name(c1.getString(c1
                            .getColumnIndex("item_name")));
                    expencesListItems.setTotal_price(c1.getString(c1
                            .getColumnIndex("total_expences")));
                    expencesListItems.add(expencesListItems);

                } while (c1.moveToNext());
            }

        }


        ExpencesListAdapter expenceslistadapter = new ExpencesListAdapter(
                DisplayListActivity.this,expencesList);
        lvExpencesListView.setAdapter(expenceslistadapter);


    }

    public void showWeeklyExpences() {

        ArrayList<ExpencesListItems> expencesList = new ArrayList<ExpencesListItems>();
        expencesList.clear();
        String query = "SELECT * FROM Expences WHERE date BETWEEN datetime('now', '-6 days') AND datetime('now', 'localtime')";

        Cursor c1 = sqlHandler.selectQuery(query);
        if (c1 != null && c1.getCount() != 0) {
            if (c1.moveToFirst()) {
                do {
                    ExpencesListItems expencesListItems = new ExpencesListItems();

                    expencesListItems.setSlno(c1.getString(c1
                            .getColumnIndex("slno")));
                    expencesListItems.setItem_name(c1.getString(c1
                            .getColumnIndex("item_name")));
                    expencesListItems.setTotal_price(c1.getString(c1
                            .getColumnIndex("total_expences")));
                    expencesListItems.add(expencesListItems);

                } while (c1.moveToNext());
            }

        }


        ExpencesListAdapter expenceslistadapter = new ExpencesListAdapter(
                DisplayListActivity.this,expencesList);
        lvExpencesListView.setAdapter(expenceslistadapter);


    }

    public void showMonthlyExpences() {

        ArrayList<ExpencesListItems> expencesList = new ArrayList<ExpencesListItems>();
        expencesList.clear();
        String query = "SELECT * FROM Expences WHERE date BETWEEN datetime('now', 'start of month') AND datetime('now', 'localtime')";

        Cursor c1 = sqlHandler.selectQuery(query);
        if (c1 != null && c1.getCount() != 0) {
            if (c1.moveToFirst()) {
                do {
                    ExpencesListItems expencesListItems = new ExpencesListItems();

                    expencesListItems.setSlno(c1.getString(c1
                            .getColumnIndex("slno")));
                    expencesListItems.setItem_name(c1.getString(c1
                            .getColumnIndex("item_name")));
                    expencesListItems.setTotal_price(c1.getString(c1
                            .getColumnIndex("total_expences")));
                    expencesListItems.add(expencesListItems);

                } while (c1.moveToNext());
            }

        }


        ExpencesListAdapter expenceslistadapter = new ExpencesListAdapter(
                DisplayListActivity.this,expencesList);
        lvExpencesListView.setAdapter(expenceslistadapter);


    }





}
